console.log("hi functions");

/// functions ///

 /* open all search engines */
 function openAll() {  
     // for Goolge appear from the left, the search engines need be in reversed order.
   //  $("#btn-open-all").trigger("click");
     
    window.open("https://duckduckgo.com/?q=-&iax=images&ia=images", "DuckDuckGo");
    window.open("https://yandex.com/images", "Yandex");
    window.open("https://search.aol.com/aol/image?query=-", "Aol");
    window.open("https://www.bing.com/images", "Bing");
    window.open("https://images.google.com", "Google");
}

function performSearch() {
    searchWord =  $("#input-user-search").val();

    let stringGoogleSearch;
    let stringBingSearch;
    let stringAolSearch;
    let stringYandexSearch; 
    let stringDuckDuckGoSearch;


    stringGoogleSearch = 'https://www.google.com/search?tbm=isch&q=' + searchWord;
    stringBingSearch = 'https://www.bing.com/images/search?q=' + searchWord;
    stringAolSearch = 'https://search.aol.com/aol/image?query=' + searchWord;
    stringYandexSearch = 'https://yandex.ru/images/search?text=' + searchWord;
    stringDuckDuckGoSearch = 'https://duckduckgo.com/?q=' + searchWord + '&iax=images&ia=images';

    window.open(stringDuckDuckGoSearch, "DuckDuckGo");
    window.open(stringYandexSearch, "Yandex");
    window.open(stringAolSearch, "Aol");
    window.open(stringBingSearch, "Bing");
    window.open(stringGoogleSearch, "Google");
}

function keyboardEvents() {


   if ( userPressedKey === 13) {  // 13 = enter
    performSearch();
   }

}