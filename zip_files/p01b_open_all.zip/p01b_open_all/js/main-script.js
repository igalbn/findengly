console.log("hi Findengly");

// variables declaration //
 let searchWord = ''; // waht user type in input

// search buttons //

$("#btn-open-all").click(function(){
    openAll();
});

$("#btn-search").click(function(){
    performSearch();
});




