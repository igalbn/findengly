console.log("hi Findengly");

// variables declaration //
 let searchWord = ''; // waht user type in input
 let userPressedKey;

// search buttons //

$("#btn-open-all").click(function(){
    openAll();
});

$("#btn-search").click(function(){
    performSearch();
});

$("html").keydown(function(key){
    userPressedKey = key.which;
    console.log("userPressedKey" + userPressedKey);
    keyboardEvents();
});



